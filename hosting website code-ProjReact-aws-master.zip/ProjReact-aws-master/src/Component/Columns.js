import React from 'react'

function Columns() {
  return (
    <React.Fragment>
      <td>Name</td>
      <td>Vishwas</td>
    </React.Fragment>
  )
}


// function Columns(params) {
//     const items = []
//     return (
//         <React.Fragment>
//         {
//             items.map(item =>
//                 <React.Fragment>
//                     <h1></h1>
//                 </React.Fragment>
//              )


//         }
//         </React.Fragment>
//     )

    
// }

export default Columns