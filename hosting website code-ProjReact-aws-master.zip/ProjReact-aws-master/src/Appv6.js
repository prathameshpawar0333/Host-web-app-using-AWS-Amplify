import React from "react";
import Appchild from "./Appchild";

//version 5 for function
const Appv6 = () => {
  return (
    <div>
      <h1> this function is of new version v6</h1>
      <Appchild />
    </div>
  );
};

export default Appv6;
