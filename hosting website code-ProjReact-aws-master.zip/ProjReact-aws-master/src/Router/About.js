import React,{Component} from 'react'

class About extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            
            <h1>Atul , Boby,Viswnath good Morning</h1>
         );
    }
}
 
export default About;
