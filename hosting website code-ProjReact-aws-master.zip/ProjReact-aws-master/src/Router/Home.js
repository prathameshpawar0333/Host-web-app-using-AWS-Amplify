import React, { Component } from "react";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  
  render() {
    return <h1> this is Home page</h1>;
  }
}

export default Home;
