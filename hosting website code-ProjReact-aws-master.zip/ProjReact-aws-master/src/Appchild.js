import React from "react";

//version 5 for function
function Appchild(props) {
  return (
    <div>
      <h1> this is child : {props.name}</h1>
    </div>
  );
}

export default Appchild;
